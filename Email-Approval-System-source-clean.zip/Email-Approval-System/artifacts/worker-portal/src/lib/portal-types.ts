export type Role = "admin" | "worker";
export type UserStatus = "pending" | "approved" | "rejected" | "inactive";
export type UserTier = 1 | 2 | 3;
export type SubmissionStatus = "pending" | "approved" | "rejected";
export type WithdrawalStatus = "pending" | "processing" | "success" | "rejected";

export type PortalUser = {
  uid: string;
  name: string;
  email: string;
  phone?: string;
  role: Role;
  status: UserStatus;
  tier: UserTier;
  balance: number;
  createdAt?: unknown;
};

export type EmailSubmission = {
  id: string;
  workerId: string;
  email: string;
  password: string;
  status: SubmissionStatus;
  submittedAt?: unknown;
  reviewedAt?: unknown;
  reviewNote?: string;
};

export type Withdrawal = {
  id: string;
  workerId: string;
  amount: number;
  method: string;
  account: string;
  status: WithdrawalStatus;
  requestedAt?: unknown;
  processedAt?: unknown;
  note?: string;
};