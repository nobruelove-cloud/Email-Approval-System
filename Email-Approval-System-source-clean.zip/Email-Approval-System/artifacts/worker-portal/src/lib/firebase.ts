import React, { useState } from "react";
import { Send, AlertCircle, ShieldAlert, CheckCircle2 } from "lucide-react";

export default function CredentialSubmitForm() {
  const [emailsText, setEmailsText] = useState("");
  const [password, setPassword] = useState("");
  const [paymentMethod, setPaymentMethod] = useState("DANA");
  const [accountNumber, setAccountNumber] = useState("");
  const [statusMsg, setStatusMsg] = useState<{ type: "success" | "error"; text: string } | null>(null);

  // Aturan / Rules kerja (Dapat disesuaikan atau diambil dari state Admin)
  const adminRules = [
    "Pastikan seluruh email yang dimasukkan statusnya aktif.",
    "Gunakan password yang sama untuk seluruh daftar email dalam satu kali kirim.",
    "Format pengiriman: Satu email per baris (atau dipisahkan dengan koma).",
    "Proses verifikasi & pencairan memerlukan waktu maksimal 1x24 jam."
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setStatusMsg(null);

    // Memisahkan baris teks menjadi daftar array email
    const emailList = emailsText
      .split(/[\n,]+/)
      .map((item) => item.trim())
      .filter((item) => item.length > 0);

    if (emailList.length === 0) {
      setStatusMsg({ type: "error", text: "Mohon masukkan minimal satu alamat email." });
      return;
    }

    // TODO: Hubungkan fungsi simpan ke Firestore / Backend di sini
    console.log("Data Setoran:", {
      totalEmail: emailList.length,
      emails: emailList,
      password: password,
      paymentMethod: paymentMethod,
      accountNumber: accountNumber
    });

    setStatusMsg({ 
      type: "success", 
      text: `Berhasil mengirim ${emailList.length} email untuk ditinjau oleh Admin!` 
    });

    // Reset form
    setEmailsText("");
    setPassword("");
  };

  return (
    <div className="max-w-2xl mx-auto p-4 space-y-6">
      
      {/* KOTAK ATURAN & RULES KERJA (DARI ADMIN) */}
      <div className="bg-amber-50 border border-amber-200 rounded-2xl p-5 shadow-sm">
        <div className="flex items-center gap-2 mb-3 text-amber-900 font-bold text-base">
          <ShieldAlert className="w-5 h-5 text-amber-600" />
          <span>Aturan & Ketentuan Setor Email</span>
        </div>
        <ul className="space-y-1.5 text-xs sm:text-sm text-amber-800 list-disc list-inside">
          {adminRules.map((rule, idx) => (
            <li key={idx} className="leading-relaxed">{rule}</li>
          ))}
        </ul>
      </div>

      {/* FORM SETORAN CREDENTIALS */}
      <div className="bg-white rounded-2xl border border-gray-100 p-6 shadow-sm">
        <div className="mb-6">
          <h2 className="text-xl font-bold text-gray-900">Detail Akun Setoran</h2>
          <p className="text-xs sm:text-sm text-gray-500 mt-1">
            Masukkan kredensial akun yang ingin Anda serahkan ke sistem.
          </p>
        </div>

        {statusMsg && (
          <div className={`p-4 rounded-xl text-xs sm:text-sm mb-5 flex items-center gap-2 ${
            statusMsg.type === "success" 
              ? "bg-green-50 text-green-700 border border-green-200" 
              : "bg-red-50 text-red-700 border border-red-200"
          }`}>
            {statusMsg.type === "success" ? <CheckCircle2 className="w-4 h-4" /> : <AlertCircle className="w-4 h-4" />}
            <span>{statusMsg.text}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-5">
          {/* TEXTAREA EMAIL BANYAK */}
          <div>
            <label className="block text-xs font-semibold text-gray-700 mb-1.5 uppercase tracking-wider">
              Daftar Alamat Email (Bisa Banyak)
            </label>
            <textarea
              rows={5}
              value={emailsText}
              onChange={(e) => setEmailsText(e.target.value)}
              placeholder={`Contoh:\nworker1@gmail.com\nworker2@gmail.com\nworker3@gmail.com`}
              className="w-full p-3.5 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:bg-white focus:outline-none focus:ring-2 focus:ring-amber-500 font-mono transition"
              required
            />
            <span className="text-[11px] text-gray-400 mt-1 block">
              Gunakan baris baru untuk memisahkan setiap email.
            </span>
          </div>

          {/* INPUT PASSWORD */}
          <div>
            <label className="block text-xs font-semibold text-gray-700 mb-1.5 uppercase tracking-wider">
              Kata Sandi Akun
            </label>
            <input
              type="text"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Masukkan kata sandi untuk akun di atas"
              className="w-full p-3.5 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:bg-white focus:outline-none focus:ring-2 focus:ring-amber-500 transition"
              required
            />
          </div>

          {/* OPSI E-WALLET & BANK */}
          <div className="pt-2 border-t border-gray-100">
            <label className="block text-xs font-semibold text-gray-700 mb-2 uppercase tracking-wider">
              Metode Pembayaran Pencairan
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 mb-3">
              {["DANA", "OVO", "GoPay", "ShopeePay", "LinkAja", "Bank Transfer"].map((method) => (
                <button
                  type="button"
                  key={method}
                  onClick={() => setPaymentMethod(method)}
                  className={`p-2.5 rounded-xl border text-xs font-medium transition ${
                    paymentMethod === method
                      ? "border-amber-500 bg-amber-50 text-amber-700 font-bold"
                      : "border-gray-200 bg-gray-50 text-gray-600 hover:bg-gray-100"
                  }`}
                >
                  {method}
                </button>
              ))}
            </div>

            <input
              type="text"
              value={accountNumber}
              onChange={(e) => setAccountNumber(e.target.value)}
              placeholder={`Nomor HP ${paymentMethod} / Rekening`}
              className="w-full p-3.5 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:bg-white focus:outline-none focus:ring-2 focus:ring-amber-500 transition"
              required
            />
          </div>

          {/* TOMBOL SUBMIT */}
          <button
            type="submit"
            className="w-full bg-amber-600 hover:bg-amber-700 text-white font-semibold py-3.5 rounded-xl text-sm transition flex items-center justify-center gap-2 shadow-sm"
          >
            <Send className="w-4 h-4" />
            <span>Kirim untuk Ditinjau</span>
          </button>
        </form>
      </div>
    </div>
  );
}
