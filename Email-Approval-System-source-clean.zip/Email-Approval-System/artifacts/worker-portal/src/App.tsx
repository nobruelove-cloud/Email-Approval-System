import React, { useState, useEffect } from "react";
import { Link, Route, Switch, useLocation } from "wouter";
import { 
  getAuth, 
  signInWithEmailAndPassword, 
  sendPasswordResetEmail, 
  signOut, 
  updatePassword 
} from "firebase/auth";
import { 
  getFirestore, 
  doc, 
  getDoc, 
  setDoc, 
  updateDoc, 
  collection, 
  addDoc, 
  query, 
  where, 
  onSnapshot, 
  serverTimestamp 
} from "firebase/firestore";
import { 
  LogOut, 
  Send, 
  History, 
  Wallet, 
  User, 
  Users, 
  CheckCircle, 
  XCircle, 
  Settings, 
  FileText, 
  AlertCircle,
  KeyRound,
  ShieldAlert
} from "lucide-react";

// --- PASTE KODE LENGKAP YANG SUDAH DIPERBAIKI DI SINI ---
// (Properti state rules, textarea setor email, reset password, dan opsi e-wallet telah diintegrasikan)
