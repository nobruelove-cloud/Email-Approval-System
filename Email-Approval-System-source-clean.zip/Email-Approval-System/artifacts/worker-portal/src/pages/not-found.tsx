import React, { useState } from "react";

export default function SubmitEmailPage() {
  const [emailsText, setEmailsText] = useState("");
  const [password, setPassword] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Pisahkan email berdasarkan baris baru atau koma
    const emailList = emailsText
      .split(/[\n,]+/)
      .map((e) => e.trim())
      .filter((e) => e.length > 0);

    console.log("Daftar Email:", emailList);
    console.log("Password:", password);
    // Masukkan fungsi Firebase / API submit Anda di sini
  };

  return (
    <div className="max-w-md mx-auto p-4">
      {/* PENGUMUMAN RULES DARI ADMIN */}
      <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 mb-6">
        <h3 className="font-bold text-amber-900 text-sm mb-1">📌 Aturan & Rules Kerja:</h3>
        <p className="text-xs text-amber-800 leading-relaxed">
          1. Pastikan email yang disetor aktif dan sesuai format.<br />
          2. Gunakan satu password yang sama untuk seluruh daftar email yang dikirim.<br />
          3. Proses verifikasi memakan waktu maksimal 1x24 jam.
        </p>
      </div>

      {/* FORM SETOR EMAIL */}
      <div className="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm">
        <div className="mb-4">
          <h2 className="text-lg font-bold text-gray-900">Detail Akun Setoran</h2>
          <p className="text-xs text-gray-500">Masukkan satu atau banyak email sekaligus.</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-gray-700 mb-1">
              Daftar Alamat Email (Satu per baris)
            </label>
            <textarea
              rows={5}
              value={emailsText}
              onChange={(e) => setEmailsText(e.target.value)}
              placeholder={`worker1@example.com\nworker2@example.com\nworker3@example.com`}
              className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"
              required
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-gray-700 mb-1">
              Kata Sandi Akun
            </label>
            <input
              type="text"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Masukkan kata sandi akun"
              className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"
              required
            />
          </div>

          <button
            type="submit"
            className="w-full bg-amber-600 hover:bg-amber-700 text-white font-semibold py-3 rounded-xl text-sm transition"
          >
            Kirim untuk Ditinjau →
          </button>
        </form>
      </div>
    </div>
  );
}
