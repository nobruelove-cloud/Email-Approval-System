import { useEffect, useMemo, useState } from "react";
import { onAuthStateChanged, signOut, type User as FirebaseUser } from "firebase/auth";
import { collection, doc, onSnapshot, orderBy, query, serverTimestamp, setDoc, updateDoc, where, addDoc, deleteDoc } from "firebase/firestore";
import { auth, createWorkerAuthAccount, db, firebaseConfigured } from "@/lib/firebase";
import type { EmailSubmission, PortalUser, Withdrawal, SubmissionStatus, WithdrawalStatus } from "@/lib/portal-types";

export function usePortalAuth() {
  const [firebaseUser, setFirebaseUser] = useState<FirebaseUser | null>(null);
  const [profile, setProfile] = useState<PortalUser | null>(null);
  const [loading, setLoading] = useState(firebaseConfigured);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!auth || !db) { setLoading(false); return; }
    const firestore = db;
    return onAuthStateChanged(auth, async (user) => {
      setFirebaseUser(user);
      if (!user) { setProfile(null); setLoading(false); return; }
      const unsubscribeProfile = onSnapshot(doc(firestore, "users", user.uid), (snapshot) => {
        setProfile(snapshot.exists() ? ({ uid: user.uid, ...snapshot.data() } as PortalUser) : null);
        setLoading(false);
      }, (reason) => {
        setError(reason instanceof Error ? reason.message : "Could not load your profile.");
        setLoading(false);
      });
      return unsubscribeProfile;
    });
  }, []);

  return { firebaseUser, profile, loading, error, configured: firebaseConfigured, logout: () => auth ? signOut(auth) : Promise.resolve() };
}

export function useCollection<T>(collectionName: string, constraints: ReturnType<typeof where>[] = [], enabled = true) {
  const [data, setData] = useState<T[]>([]);
  const [loading, setLoading] = useState(enabled && !!db);
  const [error, setError] = useState("");
  useEffect(() => {
    if (!db || !enabled) { setLoading(false); return; }
    setLoading(true);
    const base = collection(db, collectionName);
    const q = constraints.length ? query(base, ...constraints) : query(base, orderBy("createdAt", "desc"));
    return onSnapshot(q, (snapshot) => {
      setData(snapshot.docs.map((item) => ({ id: item.id, ...item.data() }) as T));
      setLoading(false);
    }, (reason) => { setError(reason instanceof Error ? reason.message : "Could not read this collection."); setLoading(false); });
  }, [collectionName, enabled, JSON.stringify(constraints)]);
  return { data, loading, error };
}

export function useWorkerData(uid?: string) {
  const submissions = useCollection<EmailSubmission>("emailSubmissions", uid ? [where("workerId", "==", uid)] : [], !!uid);
  const withdrawals = useCollection<Withdrawal>("withdrawals", uid ? [where("workerId", "==", uid)] : [], !!uid);
  return { submissions, withdrawals };
}

export function useAdminData() {
  const users = useCollection<PortalUser>("users", [], true);
  const submissions = useCollection<EmailSubmission>("emailSubmissions", [], true);
  const withdrawals = useCollection<Withdrawal>("withdrawals", [], true);
  return { users, submissions, withdrawals };
}

export async function createSubmission(payload: Omit<EmailSubmission, "id">) {
  if (!db) throw new Error("Firebase is not configured.");
  return addDoc(collection(db, "emailSubmissions"), { ...payload, submittedAt: serverTimestamp(), status: "pending" });
}

export async function createWithdrawal(payload: Omit<Withdrawal, "id">) {
  if (!db) throw new Error("Firebase is not configured.");
  return addDoc(collection(db, "withdrawals"), { ...payload, requestedAt: serverTimestamp(), status: "pending" });
}

export async function updateSubmission(id: string, status: SubmissionStatus, reviewNote: string) {
  if (!db) throw new Error("Firebase is not configured.");
  return updateDoc(doc(db, "emailSubmissions", id), { status, reviewNote, reviewedAt: serverTimestamp() });
}

export async function updateWithdrawal(id: string, status: WithdrawalStatus, note: string) {
  if (!db) throw new Error("Firebase is not configured.");
  return updateDoc(doc(db, "withdrawals", id), { status, note, processedAt: serverTimestamp() });
}

export async function updatePortalUser(uid: string, data: Partial<PortalUser>) {
  if (!db) throw new Error("Firebase is not configured.");
  return updateDoc(doc(db, "users", uid), data);
}

export async function createPortalUser(uid: string, data: Omit<PortalUser, "uid">) {
  if (!db) throw new Error("Firebase is not configured.");
  return setDoc(doc(db, "users", uid), { uid, ...data, createdAt: serverTimestamp() });
}

export async function createWorkerAccount(data: { name: string; email: string; password: string; phone?: string; tier: 1 | 2 | 3; status: "pending" | "approved" | "rejected" | "inactive"; balance: number }) {
  if (!db) throw new Error("Firebase is not configured.");
  const uid = await createWorkerAuthAccount(data.email, data.password);
  await createPortalUser(uid, {
    name: data.name,
    email: data.email,
    phone: data.phone,
    role: "worker",
    status: data.status,
    tier: data.tier,
    balance: data.balance,
  });
  return uid;
}

export async function deletePortalUser(uid: string) {
  if (!db) throw new Error("Firebase is not configured.");
  return deleteDoc(doc(db, "users", uid));
}

export async function saveSettings(name: string, data: Record<string, unknown>) {
  if (!db) throw new Error("Firebase is not configured.");
  return setDoc(doc(db, "settings", name), data, { merge: true });
}

export function useSettings<T>(name: string, initial: T) {
  const [data, setData] = useState<T>(initial);
  const [loading, setLoading] = useState(!!db);
  const [error, setError] = useState("");
  useEffect(() => {
    if (!db) { setLoading(false); return; }
    return onSnapshot(doc(db, "settings", name), (snapshot) => {
      if (snapshot.exists()) setData(snapshot.data() as T);
      setLoading(false);
    }, (reason) => { setError(reason instanceof Error ? reason.message : "Could not read settings."); setLoading(false); });
  }, [name]);
  return { data, setData, loading, error };
}